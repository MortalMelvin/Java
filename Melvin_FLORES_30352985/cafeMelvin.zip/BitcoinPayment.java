package cafeMelvin;

public class BitcoinPayment implements Payable{

	public void pay() {
		System.out.println ("Bitcoin is paying");
	}
}
