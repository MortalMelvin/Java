package cafeMelvin;

public interface Payable {
	public abstract void pay();

}
