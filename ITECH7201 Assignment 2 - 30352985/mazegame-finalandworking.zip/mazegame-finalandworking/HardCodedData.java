package mazegame;

import mazegame.boundary.IMazeData;
import mazegame.entity.*;
import mazegame.entity.utility.*;

public class HardCodedData implements IMazeData {
	private Location startUpMelvin;
	
	private Location swedes;
	private Location wulfings;
	private Location danes;
	private Location jutes;
	
	private Location angles;
	private Location frisians;

	public HardCodedData()
	{
		createLocations();
		createShops();
		populateWeightLimitTable();
		populateStrengthTable();
		populateAgilityTable();
	}
	
	public Location getStartingLocation()
	{
		return startUpMelvin;
	}
	
	public String getWelcomeMessage()
	{
		return "Welcome to the Geats Olympus";
	}
	
	private void createLocations () 
	{
		// Starting Location
		startUpMelvin = new Location ("\n\nA library with books thrown everywhere, how anyone can study here efficiently is a great puzzle", "Melvins Library");

		// Locations situated East and West from Melvins Library
		wulfings = new Location ("\n\nA greenery of plains, with well maintained grass and blossoming flowers", "Wulfings Plains");
		jutes = new Location ("\n\nA riverbank with murkish water splashing across the edge of the Mangrove trees", "Jutes Riverbed");
		
		// South Location of Danes Stonewood Shop
		angles = new Location ("\n\nA peninsula containing flying fishes, talking dolphins and wailing butandings", "Angles Island");

		// West Location of Jutes
		frisians = new Location ("\n\nA castle in a hill made with glistening glow of golds and sparkling diamonds", "Frisian Palace");

		// Connect Locations 
		// Locations connecting to Melvins Library 
		startUpMelvin.getExitCollection().addExit("east",  new Exit ("you see flower buds and cut grass to the east", wulfings));
		wulfings.getExitCollection().addExit("west", new Exit("you see a books in the tables and chairs to the west", startUpMelvin));

		startUpMelvin.getExitCollection().addExit("west", new Exit("you see waves of water to the west", jutes));
        jutes.getExitCollection().addExit("east", new Exit("you see stacked books to the east", startUpMelvin));

		// Locations connecting to Jutes 
        jutes.getExitCollection().addExit("west", new Exit("you see a road made of golden bricks", frisians));
        frisians.getExitCollection().addExit("east", new Exit("you see water creatures playing in the sea to the east", jutes));

	}
	
	private void createShops () 
	{
		// Shops situated North and South from Melvins Library 
		danes = new Blacksmith ("\n\nA wide shop space containing rune stones and carvings in wood and various items like weapons, armors, shields, utensils and jewellery", "Danes Stonewood Shop");
		swedes = new Blacksmith ("\n\nA shop colosseum, scattered all over the theatre were different kinds of weapons, armors, and shields, as well as rubbles of ravertine limestone, tuff, and brick-faced concrete", "Swedes Amphitheatre Shop");

		// Connect Locations and Shops
		// Locations and Shops connecting to Melvins Library 
		startUpMelvin.getExitCollection().addExit("north", new Exit("you see a shop of weapons, armors and shields which are full of rocks and bricks to the north", swedes));
        swedes.getExitCollection().addExit("south", new Exit("you see books on top of one another to the south", startUpMelvin));

		startUpMelvin.getExitCollection().addExit("south",  new Exit ("you see a shop with stones carvings of a spear and sword to the south", danes));
		danes.getExitCollection().addExit("north", new Exit("you see a pile of books to the north", startUpMelvin));
		
		// Locations connecting to Danes Stonewood Shop 
        danes.getExitCollection().addExit("south", new Exit("you see a bunch of Mangrove trees the south", angles));
        angles.getExitCollection().addExit("north", new Exit("you see a shop with stone menu of weapons and wood menu of armor and shields", danes));

        danes.getExitCollection().addExit("northwest", new Exit("you see a bunch of Mangrove trees the northwest", jutes));
        jutes.getExitCollection().addExit("southeast", new Exit("you see a shop with wood carvings of shields and rusted axe to the southeast", danes));

	}
	
	 private void populateStrengthTable()
     {
         StrengthTable strengthModifiers = StrengthTable.getInstance();
         strengthModifiers.setModifier(1, -5);
         strengthModifiers.setModifier(2, -4);
         strengthModifiers.setModifier(3, -4);
         strengthModifiers.setModifier(4, -3);
         strengthModifiers.setModifier(5, -3);
         strengthModifiers.setModifier(6, -2);
         strengthModifiers.setModifier(7, -2);
         strengthModifiers.setModifier(8, -1);
         strengthModifiers.setModifier(9, -1);
         strengthModifiers.setModifier(10, 0);
         strengthModifiers.setModifier(11, 0);
         strengthModifiers.setModifier(12, 1);
         strengthModifiers.setModifier(13, 1);
         strengthModifiers.setModifier(14, 2);
         strengthModifiers.setModifier(15, 2);
         strengthModifiers.setModifier(16, 3);
         strengthModifiers.setModifier(17, 3);
         strengthModifiers.setModifier(18, 4);
         strengthModifiers.setModifier(19, 4);
         strengthModifiers.setModifier(20, 5);
         strengthModifiers.setModifier(21, 5);
         strengthModifiers.setModifier(22, 5);
         strengthModifiers.setModifier(23, 5);
         strengthModifiers.setModifier(24, 5);
         strengthModifiers.setModifier(25, 5);
         strengthModifiers.setModifier(26, 8);
         strengthModifiers.setModifier(27, 8);
         strengthModifiers.setModifier(28, 8);
         strengthModifiers.setModifier(29, 8);
         strengthModifiers.setModifier(30, 10);
         strengthModifiers.setModifier(31, 10);
         strengthModifiers.setModifier(32, 10);
         strengthModifiers.setModifier(33, 10);
         strengthModifiers.setModifier(34, 10);
         strengthModifiers.setModifier(35, 10);
         strengthModifiers.setModifier(36, 12);
         strengthModifiers.setModifier(37, 12);
         strengthModifiers.setModifier(38, 12);
         strengthModifiers.setModifier(39, 12);
         strengthModifiers.setModifier(40, 12);
         strengthModifiers.setModifier(41, 15);
         strengthModifiers.setModifier(42, 15);
         strengthModifiers.setModifier(43, 15);
         strengthModifiers.setModifier(44, 17);
         strengthModifiers.setModifier(45, 17);
         strengthModifiers.setModifier(46, 18);
     }

     private void populateAgilityTable()
     {
         AgilityTable agilityModifiers = AgilityTable.GetInstance();
         agilityModifiers.SetModifier(1, -5);
         agilityModifiers.SetModifier(2, -5);
         agilityModifiers.SetModifier(3, -5);
         agilityModifiers.SetModifier(4, -3);
         agilityModifiers.SetModifier(5, -3);
         agilityModifiers.SetModifier(6, -2);
         agilityModifiers.SetModifier(7, -2);
         agilityModifiers.SetModifier(8, -1);
         agilityModifiers.SetModifier(9, -1);
         agilityModifiers.SetModifier(10, 0);
         agilityModifiers.SetModifier(11, 0);
         agilityModifiers.SetModifier(12, 1);
         agilityModifiers.SetModifier(13, 1);
         agilityModifiers.SetModifier(14, 2);
         agilityModifiers.SetModifier(15, 2);
         agilityModifiers.SetModifier(16, 3);
         agilityModifiers.SetModifier(17, 3);
         agilityModifiers.SetModifier(18, 4);
         agilityModifiers.SetModifier(19, 4);
         agilityModifiers.SetModifier(20, 6);
         agilityModifiers.SetModifier(21, 6);
         agilityModifiers.SetModifier(22, 6);
         agilityModifiers.SetModifier(23, 6);
         agilityModifiers.SetModifier(24, 6);
         agilityModifiers.SetModifier(25, 6);
         agilityModifiers.SetModifier(26, 8);
         agilityModifiers.SetModifier(27, 8);
         agilityModifiers.SetModifier(28, 8);
         agilityModifiers.SetModifier(29, 8);
         agilityModifiers.SetModifier(30, 8);
         agilityModifiers.SetModifier(31, 8);
         agilityModifiers.SetModifier(32, 11);
         agilityModifiers.SetModifier(33, 11);
         agilityModifiers.SetModifier(34, 11);
         agilityModifiers.SetModifier(35, 11);
         agilityModifiers.SetModifier(36, 11);
         agilityModifiers.SetModifier(37, 11);
         agilityModifiers.SetModifier(38, 13);
         agilityModifiers.SetModifier(39, 13);
         agilityModifiers.SetModifier(40, 13);
         agilityModifiers.SetModifier(41, 13);
         agilityModifiers.SetModifier(42, 13);
         agilityModifiers.SetModifier(43, 13);
         agilityModifiers.SetModifier(44, 15);
         agilityModifiers.SetModifier(45, 15);
         agilityModifiers.SetModifier(46, 15);
     }

     private void populateWeightLimitTable()
     {
         WeightLimit weightModifier = WeightLimit.getInstance();
         weightModifier.setModifier(1, 6);
         weightModifier.setModifier(2, 13);
         weightModifier.setModifier(3, 20);
         weightModifier.setModifier(4, 26);
         weightModifier.setModifier(5, 33);
         weightModifier.setModifier(6, 40);
         weightModifier.setModifier(7, 46);
         weightModifier.setModifier(8, 53);
         weightModifier.setModifier(9, 60);
         weightModifier.setModifier(10, 66);
         weightModifier.setModifier(11, 76);
         weightModifier.setModifier(12, 86);
         weightModifier.setModifier(13, 100);
         weightModifier.setModifier(14, 116);
         weightModifier.setModifier(15, 133);
         weightModifier.setModifier(16, 153);
         weightModifier.setModifier(17, 173);
         weightModifier.setModifier(18, 200);
         weightModifier.setModifier(19, 233);
         weightModifier.setModifier(20, 266);
         weightModifier.setModifier(21, 306);
         weightModifier.setModifier(22, 346);
         weightModifier.setModifier(23, 400);
         weightModifier.setModifier(24, 466);
         weightModifier.setModifier(25, 533);
         weightModifier.setModifier(26, 613);
         weightModifier.setModifier(27, 693);
         weightModifier.setModifier(28, 800);
         weightModifier.setModifier(29, 933);
         weightModifier.setModifier(30, 1013);
         weightModifier.setModifier(31, 1093);
         weightModifier.setModifier(32, 1300);
         weightModifier.setModifier(33, 1433);
         weightModifier.setModifier(34, 1513);
         weightModifier.setModifier(35, 1593);
         weightModifier.setModifier(36, 1700);
         weightModifier.setModifier(37, 1833);
         weightModifier.setModifier(38, 1913);
         weightModifier.setModifier(39, 1993);
         weightModifier.setModifier(40, 2100);
         weightModifier.setModifier(41, 2233);
         weightModifier.setModifier(42, 2313);
         weightModifier.setModifier(43, 2393);
         weightModifier.setModifier(44, 2500);
         weightModifier.setModifier(45, 2633);
         weightModifier.setModifier(46, 2713);
     }
}
