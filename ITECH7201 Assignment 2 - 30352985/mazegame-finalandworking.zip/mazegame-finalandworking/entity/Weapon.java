package mazegame.entity;

public class Weapon extends Item {
	
	public Dice m_Dice;

    public Weapon(String label, int value, double weight, String description, boolean isWearable, String wearLocation) {
         super (label, value, weight, description, isWearable, wearLocation);
    }
}
