package mazegame.entity;

public abstract class Item {
	
	private String label = "Item";
	private int value = 0;
	private double weight = 0;
	private String description = "";
	private boolean isWearable = false;
	private String wearLocation = "";

	public Item ()
	{
		this.label = label;
		this.value = value;
		this.weight = weight;
		this.description = description;
		this.isWearable = isWearable;
		this.wearLocation = wearLocation;
	}

	
	public Item (String label, int value, double weight, String description, boolean isWearable, String wearLocation)
	{
		this.label = label;
		this.value = value;
		this.weight = weight;
		this.description = description;
		this.isWearable = isWearable;
		this.wearLocation = wearLocation;

	}

	public String getLabel() {

		return label;
	}
	
	public int getValue() 
	{
		return value;
	}
	
	public double getWeight()
	{
		return weight;
	}
	
	public String getDescription()
	{
		return description;
	}

	public boolean isWearable() {
		return isWearable;
	}

	public String getWearLocation() {
		return wearLocation;
	}
		
}
