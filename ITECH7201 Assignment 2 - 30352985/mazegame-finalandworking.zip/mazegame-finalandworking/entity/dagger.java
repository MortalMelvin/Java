package mazegame.entity;

public class dagger extends Item{
	
	private String label = "dagger";
	private int value = 1;
	private double weight = 2;
	private String description = "A short knife with a pointed and edged blade";
	private boolean isWearable = false;
	private String wearLocation = "wield";

	int damage = 4;

	public dagger()
	{
		super ();
	}

	
	public dagger(String label, int value, double weight, String description, boolean isWearable, String wearLocation)
	{
		//super (label, value, weight, description, isWearable, wearLocation);
		label = "Dagger";
		value = 1;
		weight = 2;
		description = "A short knife with a pointed and edged blade";
		isWearable = false;
		wearLocation = "wield";
		
	}


	
	
	/**
	 * @return the damage
	 */
	public int getDamage() {
		return this.damage;
	}


	public String getLabel() {

		return this.label;
	}
	
	public int getValue() 
	{
		return this.value;
	}
	
	public double getWeight()
	{
		return this.weight;
	}
	
	public String getDescription()
	{
		return this.description;
	}

	public boolean isWearable() {
		return this.isWearable;
	}

	public String getWearLocation() {
		return this.wearLocation;
	}

	
	@Override
	public String toString() {
		return "Dagger [damage=" + damage + ", getLabel()=" + getLabel() + ", getValue()=" + getValue()
				+ ", getWeight()=" + getWeight() + ", getDescription()=" + getDescription() + ", isWearable()="
				+ isWearable() + ", getWearLocation()=" + getWearLocation() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	

}
