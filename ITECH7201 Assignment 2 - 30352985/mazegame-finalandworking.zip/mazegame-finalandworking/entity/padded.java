package mazegame.entity;

public class padded extends Armor {
	private String label = "padded";
	private int value = 5;
	private double weight = 10;
	private String description = "A padded defensive jacket, worn as armor separately, or combined with mail or plate armor";
	private boolean isWearable = true;
	private String wearLocation = "body";

	private int bonus;	

	public padded (String label, int value, double weight, String description, boolean isWearable, String wearLocation) {
//		super (label, value, weight, description, isWearable, wearLocation);
		label = "padded";
		value = 5;
		weight = 10;
		description = "A padded defensive jacket, worn as armor separately, or combined with mail or plate armor";
		isWearable = true;
		wearLocation = "body";

		this.bonus = bonus;
	}
	
	public padded()
	{
		super ();
		this.bonus = bonus;
	}

	
	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}


	public String getLabel() {

		return this.label;
	}
	
	public int getValue() 
	{
		return this.value;
	}
	
	public double getWeight()
	{
		return this.weight;
	}
	
	public String getDescription()
	{
		return this.description;
	}

	public boolean isWearable() {
		return this.isWearable;
	}

	public String getWearLocation() {
		return this.wearLocation;
	}

	@Override
	public String toString() {
		return "padded [label=" + label + ", value=" + value + ", weight=" + weight + ", description=" + description
				+ ", isWearable=" + isWearable + ", wearLocation=" + wearLocation + ", bonus=" + bonus + ", getBonus()="
				+ getBonus() + ", getLabel()=" + getLabel() + ", getValue()=" + getValue() + ", getWeight()="
				+ getWeight() + ", getDescription()=" + getDescription() + ", isWearable()=" + isWearable()
				+ ", getWearLocation()=" + getWearLocation() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}

}
