package mazegame.entity;

import mazegame.entity.Item;
import java.util.ArrayList;

public class Player extends Character {
	
	private Location currentLocation;
//	public ArrayList<Item> items = new ArrayList<Item>();
	private Inventory theInventory;
	private Inventory theInventoryWorn;

	public Player()
    {
    }

    public Player(String name)
	{
	    super (name);
	    theInventory = new Inventory();
	    theInventoryWorn = new Inventory();

	}
    public Location getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(Location currentLocation) {
		this.currentLocation = currentLocation;
	}

    public Inventory getTheInventory() {
		return theInventory;
	}

	public void setTheInventory(Inventory theInventory) {
		this.theInventory =  theInventory;
	}
	
    public Inventory getTheInventoryWorn() {
		return theInventoryWorn;
	}

	public void setTheInventoryWorn(Inventory theInventoryWorn) {
		this.theInventoryWorn =  theInventoryWorn;
	}


}
