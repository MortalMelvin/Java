package mazegame.entity;

public class buckler extends Shield {
	private String label = "buckler";
	private int value = 15;
	private double weight = 1;
	private String description = "A small round shield held by a handle at arm's length";
	private boolean isWearable = true;
	private String wearLocation = "arm";

	private int bonus;	

	public buckler()
	{
		super ();
		this.bonus = bonus;
	}

	
	public buckler (String label, int value, double weight, String description, boolean isWearable, String wearLocation) {
		//super (label, value, weight, description, isWearable, wearLocation);
		label = "buckler";
		value = 15;
		weight = 1;
		description = "A small round shield held by a handle at arm's length";
		isWearable = true;
		wearLocation = "arm";
		this.bonus = bonus;
	}
	

	
	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}


	public String getLabel() {

		return this.label;
	}
	
	public int getValue() 
	{
		return this.value;
	}
	
	public double getWeight()
	{
		return this.weight;
	}
	
	public String getDescription()
	{
		return this.description;
	}

	public boolean isWearable() {
		return this.isWearable;
	}

	public String getWearLocation() {
		return this.wearLocation;
	}

	@Override
	public String toString() {
		return "buckler [label=" + label + ", value=" + value + ", weight=" + weight + ", description=" + description
				+ ", isWearable=" + isWearable + ", wearLocation=" + wearLocation + ", bonus=" + bonus + "]";
	}


}
