package mazegame.entity;

public class Shield extends Item {
	
	private int bonus;	

	public Shield () {
		super ();
		this.bonus = bonus;
	}

	public Shield (String label, int value, double weight, String description, boolean isWearable, String wearLocation) {
		super (label, value, weight, description, isWearable, wearLocation);
		this.bonus = bonus;
	}
}
