package mazegame.entity;

public class Armor extends Item {
	private int bonus;	

	public Armor () {
		super ();
		this.bonus = bonus;
	}

	public Armor (String label, int value, double weight, String description, boolean isWearable, String wearLocation) {
		super (label, value, weight, description, isWearable, wearLocation);
		this.bonus = bonus;
	}
	
	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
}
