package mazegame.control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import mazegame.entity.Player;

public abstract class CommandState 
{
	private HashMap <String, Command>availableCommands;
	
	public abstract CommandState update (Player thePlayer);
	
	public CommandState () 
{
		availableCommands = new HashMap<String, Command> ();
	}

	public HashMap <String, Command> getAvailableCommands () 
{
		return this.availableCommands;
	}
	
	public void setAvailableCommands(HashMap<String, Command> hashmap) 
{
		availableCommands = hashmap;
	}
	
	public Command getCommand (String commandLabel) 
{
		return availableCommands.get(commandLabel);
	}
	
	public ArrayList<String> getLabels () 
{
		return new ArrayList <String>(availableCommands.keySet());
	}

	public Set<String> keySet() {
		// TODO Auto-generated method stub
		return null;
	}
}
