package mazegame.control;

import mazegame.entity.Exit;
import mazegame.entity.Inventory;
import mazegame.entity.Player;
import mazegame.entity.Item;
import mazegame.entity.dagger;
import mazegame.entity.padded;
import mazegame.entity.buckler;


public class WearCommand implements Command {


	private CommandResponse response;
	public int lifePoints = 0;
	
	public CommandResponse execute(ParsedInput userInput, Player thePlayer) {
		response = new CommandResponse("Can't determine what you are wearing here!");
		if(userInput.getArguments().size() == 0) {
			return new CommandResponse ("If you want to wear you need to tell me what.");
		}
		
		if(userInput.getArguments().size() == 1) {
			String secondArgument = (String) userInput.getArguments().get(0);
			
			//Inventory Item List
			if ((secondArgument.equals("dagger")) |
			   (secondArgument.equals("padded")) |
			   (secondArgument.equals("buckler"))) {
				
				Inventory localInventory = thePlayer.getTheInventory();
				Item localItem = localInventory.findItem(secondArgument.toString());

				if (localItem == null) {
					return new CommandResponse("Item " + secondArgument + " not existing");
				}
				else {
					Inventory localInventoryWorn = thePlayer.getTheInventoryWorn();
					Item localItemWorn = localInventoryWorn.findItem(secondArgument.toString());
					if (localItemWorn == null) {
						localInventoryWorn.addItem(localItem);
						localInventory.removeItem(secondArgument.toString());
						lifePoints = lifePoints + 2;
						return new CommandResponse("You wore a " + secondArgument);

					}
					else {
						return new CommandResponse("You already have worn " + secondArgument);
					}
				}
			}

		}
		return response;
	}
}
