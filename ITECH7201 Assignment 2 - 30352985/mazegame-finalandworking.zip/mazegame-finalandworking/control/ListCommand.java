package mazegame.control;

import mazegame.entity.dagger;
import mazegame.entity.Exit;
import mazegame.entity.Inventory;
import mazegame.entity.Item;
import mazegame.entity.Player;

public class ListCommand implements Command {
	
	private CommandResponse response;
	
	public CommandResponse execute(ParsedInput userInput, Player thePlayer) {
		response = new CommandResponse("Can't find that to list at here!");
		if (userInput.getArguments().size() == 0) {
			return new CommandResponse ("If you want a list you need to tell me what.");
		}
		
		if(userInput.getArguments().size() == 1) {
			String secondArgument = (String) userInput.getArguments().get(0);

			if (secondArgument.equals("items")){ 
				
				Inventory localInventory = thePlayer.getTheInventory();
				return new CommandResponse(localInventory.printItemList());
			}
			else {
				return response;
			}

		}	
		return response;
	}
}
