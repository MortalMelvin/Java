package mazegame.control;

import mazegame.entity.Exit;
import mazegame.entity.Inventory;
import mazegame.entity.Player;
import mazegame.entity.Item;
import mazegame.entity.dagger;
import mazegame.entity.padded;
import mazegame.entity.buckler;


public class BuyCommand implements Command {


	private CommandResponse response;
	
	public CommandResponse execute(ParsedInput userInput, Player thePlayer) {
		response = new CommandResponse("Can't determine what you are buying here!");
		if(userInput.getArguments().size() == 0) {
			return new CommandResponse ("If you want to buy you need to tell me what.");
		}
		
		if(userInput.getArguments().size() == 1) {
			String secondArgument = (String) userInput.getArguments().get(0);

			Inventory localInventory = thePlayer.getTheInventory();
			Item localItem = localInventory.findItem(secondArgument.toString());
			if (localItem == null) {
				//Inventory Item List
				if ((secondArgument.equals("dagger")) |
				   (secondArgument.equals("padded")) |
				   (secondArgument.equals("buckler"))) {
					
					try {
						localInventory.addItem((Item) Class.forName("mazegame.entity." + secondArgument.toString()).newInstance());
						thePlayer.setTheInventory(localInventory);
						return new CommandResponse("You bought a " + secondArgument);
	
					} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
						e.printStackTrace();
					}
				}
				else {
					return new CommandResponse("You entered an invalid item: " + secondArgument);
				}
			}
			else {
				return new CommandResponse("You already have " + secondArgument + " in your inventory list");
			}

		}
		return response;
	}
}
