package mazegame.control;

import mazegame.entity.Exit;
import mazegame.entity.Player;


public class GetCommand implements Command {


	private CommandResponse response;
	
	public CommandResponse execute(ParsedInput userInput, Player thePlayer) {
		response = new CommandResponse("Can't determine what you are getting here!");
		if(userInput.getArguments().size() == 0) {
			return new CommandResponse ("If you want to get you need to tell me what.");
		}
		
		if(userInput.getArguments().size() == 1) {
			String secondArgument = (String) userInput.getArguments().get(0);

			if (secondArgument.equals("status")){ 
				response.setMessage(thePlayer.getCurrentLocation().toString());
				return response;
			}
			
		}
		
		for (Object argument: userInput.getArguments()) {
			if (thePlayer.getCurrentLocation().getExitCollection().containsExit(argument.toString())) {
				Exit theExit = thePlayer.getCurrentLocation().getExitCollection().getExit((String)argument);
				System.out.println ("theExit:" + theExit);
				return new CommandResponse(theExit.getDescription());
			}
		}
		return response;
	}
}

