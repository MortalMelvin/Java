package mazegame.control;

import mazegame.entity.Exit;
import mazegame.entity.Inventory;
import mazegame.entity.Player;
import mazegame.entity.Item;
import mazegame.entity.dagger;
import mazegame.entity.padded;
import mazegame.entity.buckler;


public class RemoveCommand implements Command {


	private CommandResponse response;
	
	public CommandResponse execute(ParsedInput userInput, Player thePlayer) {
		response = new CommandResponse("Can't determine what you are removing here!");
		if(userInput.getArguments().size() == 0) {
			return new CommandResponse ("If you want to remove you need to tell me what.");
		}
		
		if(userInput.getArguments().size() == 1) {
			String secondArgument = (String) userInput.getArguments().get(0);

			//Inventory Item List
			if ((secondArgument.equals("dagger")) |
			   (secondArgument.equals("padded")) |
			   (secondArgument.equals("buckler"))) {

				Inventory localInventoryWorn = thePlayer.getTheInventoryWorn();
				Item localItemWorn = localInventoryWorn.findItem(secondArgument.toString());

				if (localItemWorn == null) {
					return new CommandResponse("You are not wearing " + secondArgument);
				}
				else {
					Inventory localInventory = thePlayer.getTheInventory();
					Item localItem = localInventory.findItem(secondArgument.toString());
					if (localItem == null) {
						localInventory.addItem(localItemWorn);
						localInventoryWorn.removeItem(secondArgument.toString());
						return new CommandResponse("You removed a " + secondArgument);

					}
					else {
						return new CommandResponse("You already have " + secondArgument + " in your inventory list");
					}
				}
			}
		}
		return response;
	}
}
